package ie.app.main;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import android.app.Application;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import ie.app.models.Donation;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DonationApp extends Application
                              implements Callback<List<Donation>>
{
    public final int       target       = 10000;
    public int             totalDonated = 0;
    public List <Donation> donations    = new ArrayList<Donation>();
    //public DBManager dbManager;

    public DonationService donationService;
    public boolean         donationServiceAvailable = false;
    public String          service_url  = "http://donationweb-4-0.herokuapp.com/";
    //public String          service_url  = "http://10.0.2.2:4000";
                                            //Standard Emulator IP Address

    @Override
    public void onCreate()
    {
        super.onCreate();
        Log.v("Donate", "Donation App Started");
        //dbManager = new DBManager(this);
        Gson gson = new GsonBuilder().create();

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(service_url)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient)
                .build();

        donationService = retrofit.create(DonationService.class);

        Log.v("Donate", "Donation Service Created");

        Call<List<Donation>> call1 = (Call<List<Donation>>) donationService.getAllDonations();
        call1.enqueue(this);
    }

    @Override
    public void onResponse(Call<List<Donation>> call, Response<List<Donation>> response) {
        serviceAvailableMessage();
        Log.v("retrofit","JSON = " + response.raw());
        donations = response.body();
        calculateTotalDonated(donations);
        donationServiceAvailable = true;
    }

    @Override
    public void onFailure(Call<List<Donation>> call, Throwable t) {
        donationServiceAvailable = false;
        Log.v("retrofit",t.getMessage());
        serviceUnavailableMessage();
    }

    public void serviceUnavailableMessage()
    {
        Toast toast = Toast.makeText(this,
                "Donation Service Unavailable. Try again later",
                Toast.LENGTH_LONG);
        toast.show();
    }

    public void serviceAvailableMessage()
    {
        Toast toast = Toast.makeText(this,
                "Donation Contacted Successfully",
                Toast.LENGTH_LONG);
        toast.show();
    }

    public void calculateTotalDonated(List<Donation> donations)
    {
        for (Donation d : donations)
            totalDonated += d.amount;
    }
}