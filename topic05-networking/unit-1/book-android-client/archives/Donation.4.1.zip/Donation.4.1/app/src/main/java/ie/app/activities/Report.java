package ie.app.activities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.widget.SwipeRefreshLayout;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import ie.app.R;
import ie.app.models.Donation;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Report extends Base implements OnItemClickListener,
                                            OnClickListener,
                                            Callback<List<Donation>> {
    ListView listView;
    DonationAdapter adapter;
    SwipeRefreshLayout mSwipeRefreshLayout;
    Call<List<Donation>> call1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        mSwipeRefreshLayout = (SwipeRefreshLayout)
                            findViewById(R.id.report_swipe_refresh_layout);
        listView = (ListView) findViewById(R.id.reportList);
        listView.setOnItemClickListener(this);

        call1 = app.donationService.getAllDonations();
        call1.enqueue(this);

        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                call1 = app.donationService.getAllDonations();
                call1.enqueue(Report.this);
            }
        });

    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View row, int pos, long id) {

        String _id = row.getTag().toString();
        Call<List<Donation>> call2 = app.donationService.getDonation(_id);
        call2.enqueue(new Callback<List<Donation>>() {
                          @Override
                          public void onResponse(Call<List<Donation>> call,
                                                 Response<List<Donation>> response) {
                              Toast toast = Toast.makeText(Report.this, "Donation : " +
                                      response.body() + " Selected.", Toast.LENGTH_LONG);
                              toast.show();
                          }

                          @Override
                          public void onFailure(Call<List<Donation>> call, Throwable t) {
                              Toast toast = Toast.makeText(Report.this,
                                      "Error retrieving Donation", Toast.LENGTH_LONG);
                              toast.show();
                          }
                      }
        );
    }

    @Override
    public void onClick(View view) {
        if (view.getTag() instanceof Donation) {
            onDonationDelete((Donation) view.getTag());
        }
    }

    public void onDonationDelete(final Donation donation) {
        String stringId = donation._id;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Donation?");
        builder.setIcon(android.R.drawable.ic_delete);
        builder.setMessage("Are you sure you want to Delete the \'Donation with ID \' \n [ "
                + stringId + " ] ?");
        builder.setCancelable(false);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {


                Call<Donation> call3 = app.donationService.deleteDonation(donation._id);
                call3.enqueue(new Callback<Donation>() {
                                  @Override
                                  public void onResponse(Call<Donation> call, Response<Donation> response) {
                                      call1 = app.donationService.getAllDonations();
                                      call1.enqueue(Report.this);
                                      //adapter.notifyDataSetChanged();
                                  }

                                  @Override
                                  public void onFailure(Call<Donation> call, Throwable t) {
                                      Toast toast = Toast.makeText(Report.this, "Error deleting Donation", Toast.LENGTH_LONG);
                                      toast.show();
                                  }
                              }
                );
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onResponse(Call<List<Donation>> call, Response<List<Donation>> response) {

        app.donations = response.body();
        adapter = new DonationAdapter(this, app.donations);
        //adapter.notifyDataSetChanged();
        listView.setAdapter(adapter);

        if(mSwipeRefreshLayout.isRefreshing())
            mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onFailure(Call<List<Donation>> call, Throwable t) {
        Toast toast = Toast.makeText(this, "Error retrieving Donations", Toast.LENGTH_LONG);
        toast.show();
    }

    class DonationAdapter extends ArrayAdapter<Donation> {
        private Context context;
        public List<Donation> donations;

        public DonationAdapter(Context context, List<Donation> donations) {
            super(context, R.layout.row_donate, donations);
            this.context = context;
            this.donations = donations;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View view = inflater.inflate(R.layout.row_donate, parent, false);
            Donation donation = donations.get(position);

            ImageView imgDelete = (ImageView) view.findViewById(R.id.imgDelete);
            imgDelete.setTag(donation);
            imgDelete.setOnClickListener(Report.this);

            TextView amountView = (TextView) view.findViewById(R.id.row_amount);
            TextView methodView = (TextView) view.findViewById(R.id.row_method);
            TextView upvotesView = (TextView) view.findViewById(R.id.row_upvotes);

            amountView.setText("" + donation.amount);
            methodView.setText(donation.paymenttype);
            upvotesView.setText("" + donation.upvotes);

            view.setTag(donation._id); // setting the 'row' id to the id of the donation

            return view;
        }

        @Override
        public int getCount() {
            return donations.size();
        }
    }

}