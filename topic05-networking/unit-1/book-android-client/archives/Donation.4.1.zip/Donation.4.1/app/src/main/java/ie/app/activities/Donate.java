package ie.app.activities;

import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.View;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import ie.app.R;
import ie.app.models.Donation;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Donate extends Base implements Callback<Donation> {

    private Button              donateButton;
    private RadioGroup          paymentMethod;
    private ProgressBar         progressBar;
    private NumberPicker        amountPicker;
    private EditText            amountText;
    private TextView            amountTotal;
    private SharedPreferences   settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        donateButton = (Button) findViewById(R.id.donateButton);

        paymentMethod = (RadioGroup)   findViewById(R.id.paymentMethod);
        progressBar   = (ProgressBar)  findViewById(R.id.progressBar);
        amountPicker  = (NumberPicker) findViewById(R.id.amountPicker);
        amountText    = (EditText)     findViewById(R.id.paymentAmount);
        amountTotal   = (TextView)     findViewById(R.id.totalSoFar);

        amountPicker.setMinValue(0);
        amountPicker.setMaxValue(1000);
        progressBar.setMax(10000);
        amountTotal.setText("$" + app.totalDonated);

        settings = getSharedPreferences("loginPrefs", 0);
        String username = settings.getString("username", "");

        TextView donateUsername = (TextView) findViewById(R.id.donateUsername);

        SpannableString spanString = new SpannableString(username);
        //spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), 0);
        spanString.setSpan(new StyleSpan(Typeface.BOLD), 0, spanString.length(), 0);
        spanString.setSpan(new StyleSpan(Typeface.ITALIC), 0, spanString.length(), 0);
        donateUsername.setText(spanString);


    }

    public void donateButtonPressed (View view)
    {
        String method = paymentMethod.getCheckedRadioButtonId() == R.id.PayPal ? "PayPal" : "Direct";
        int donatedAmount =  amountPicker.getValue();
        if (donatedAmount == 0)
        {
            String text = amountText.getText().toString();
            if (!text.equals(""))
                donatedAmount = Integer.parseInt(text);
        }
        if (donatedAmount > 0)
        {
            Donation donation = new Donation(donatedAmount, method,0,0.0,0.0);

                Call<Donation> call = (Call<Donation>) app.donationService.createDonation(donation);
                call.enqueue(this);
        }

        amountText.setText("");
        amountPicker.setValue(0);
    }

    @Override
    public void reset(MenuItem item)
    {
        app.donations.clear();
        app.totalDonated = 0;
        amountTotal.setText("$" + app.totalDonated);
    }

    @Override
    public void onResponse(Call<Donation> call, Response<Donation> response)
    {
        Toast toast = Toast.makeText(this, "Donation Accepted", Toast.LENGTH_SHORT);
        toast.show();
        getAllDonations();
    }

    @Override
    public void onFailure(Call<Donation> call, Throwable t)
    {
        Toast toast = Toast.makeText(this, "Error making donation", Toast.LENGTH_LONG);
        toast.show();
    }

    public void getAllDonations() {
        Call<List<Donation>> call2 = (Call<List<Donation>>) app.donationService.getAllDonations();
        call2.enqueue(new Callback<List<Donation>>() {
            @Override
            public void onResponse(Call<List<Donation>> call, Response<List<Donation>> response) {
                Log.v("retrofit","JSON = " + response.raw());
                app.totalDonated = 0;
                app.donations = response.body();
                app.calculateTotalDonated(app.donations);
                progressBar.setProgress(app.totalDonated);
                amountTotal.setText("$" + app.totalDonated);
                amountText.setText("");
                amountPicker.setValue(0);
                app.donationServiceAvailable = true;
            }

            @Override
            public void onFailure(Call<List<Donation>> call, Throwable t) {
                app.donationServiceAvailable = false;
                Log.v("retrofit",t.getMessage());
                app.serviceUnavailableMessage();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        getAllDonations();
    }
}
